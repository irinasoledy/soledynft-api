<template>
    <div>
        <div class="col-sm-10 col-12" v-for="wishListProduct in wishListProducts" :key="wishListProduct.id">
            <div class="item">
                <a :href="'/' + $lang + '/' + site + '/catalog/' + wishListProduct.product.category.alias + '/' + wishListProduct.product.alias">
                    <img v-if="wishListProduct.product.main_image" :src="'/images/products/sm/' + wishListProduct.product.main_image.src" />
                    <img v-else src="/images/no-image-ap.jpg" alt="product" />
                </a>
                <div class="descr">
                    <a :href="'/' + $lang + '/' + site + '/catalog/' + wishListProduct.product.category.alias + '/' + wishListProduct.product.alias" class="nameProduct">{{ wishListProduct.product.translation.name }}</a>
                    <div class="price">
                        <span>{{ wishListProduct.product.personal_price.price }} </span>
                        <span>{{ wishListProduct.product.personal_price.old_price }} {{ $currency }}</span>
                    </div>
                    <add-to-cart-wish-product-mob :product="wishListProduct.product" :site="site"></add-to-cart-wish-product-mob>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { bus } from "../../../app_mobile";

    export default {
        props: ["products", "site"],
        data() {
            return {
                wishListProducts: this.products,
            };
        },
        mounted() {
            bus.$on("updateWishList", (data) => {
                this.wishListProducts = data.products;
            });
        },
        methods: {
            removeProductWish(id) {
                axios
                    .post("/" + this.$lang + "/" + this.site + "/removeProductWish", {
                        id: id,
                    })
                    .then((response) => {
                        (this.wishListProducts = response.data.products), bus.$emit("updateWishBox", response.data.products);
                    })
                    .catch((e) => {
                        console.log("error remove product");
                    });
            },
        },
    };
</script>
