<template>
    <div class="row">
        <div class="col-6" v-for="setProduct in set.set_products" :data-productid="setProduct.product.code">
            <a :href="'/' + $lang + '/' + site + '/catalog/' + setProduct.product.category.alias + '/' + setProduct.product.alias" @click="viewProductGA(product)">
                <img :src="'/images/products/sm/' + setProduct.product.set_image.src" v-if="setProduct.product.set_image" />
                <img src="/images/no-image-ap.jpg" v-else />
            </a>
            <a :href="'/' + $lang + '/' + site + '/catalog/' + setProduct.product.category.alias + '/' + setProduct.product.alias" class="nameProduct">
                {{ setProduct.product.translation.name }}
            </a>
            <a :href="'/' + $lang + '/' + site + '/catalog/' + setProduct.product.category.alias + '/' + setProduct.product.alias">{{ trans.vars.DetailsProductSet.viewProduct }}</a>
            <div class="price" v-if="setProduct.product.personal_price.old_price == setProduct.product.personal_price.price">
                <span>{{ setProduct.product.personal_price.price }}</span>
                <span>{{ $currency }}</span>
            </div>
            <div class="price" v-else>
                <span> {{ setProduct.product.personal_price.price }}</span><span></span> /
                <span>
                    {{ setProduct.product.personal_price.old_price }}
                </span>
                <span>{{ $currency }}</span>
            </div>
            <div class="gift-box" v-if="setProduct.gift == 1">
                <img src="/fronts/img/icons/giftIcon.png" alt="">
            </div>
        </div>
    </div>
</template>

<script>
    import { bus } from "../../app_mobile";
    import { Hooper, Slide, Pagination as HooperPagination } from "hooper";
    import "hooper/dist/hooper.css";

    export default {
        components: { Hooper, Slide, HooperPagination },
        props: ["set", "site"],
        data() {
            return {
                subproducts: [],
                chooseProducts: false,
                ammount: 0,
                notInStock: false,
                product: [],
                subproduct: [],
                addTocartBtn: false,
                subproductsSizeDrop: [],

            };
        },
        mounted() {},
        methods: {
            openSizesDropDown() {
                let vm = this;
                this.set.products.forEach(function (entry) {
                    if (!vm.subproductsSizeDrop.includes(entry.id)) {
                        bus.$emit("openSizesDropDown" + vm.set.id + entry.id);
                        vm.subproductsSizeDrop.push(entry.id);
                        return true;
                    }
                });
            },
            viewProductGA(product) {
                bus.$emit("ga-event-viewProduct", { product: product, actionField: 'set/Collection'});
            },
            getSetImage(product, setId) {
                return true;
                let ret = false;
                product.set_images.forEach(function (entry) {
                    if (setId == entry.set_id) {
                        ret = entry.image;
                        return ret;
                    }
                });
                return ret;
            },
        },
    };
</script>

<style media="screen">
    .check.selectedRadio {
        background-image: url(/fronts_mobile/img/backgrounds/collSize.jpg) !important;
        color: #fff !important;
    }
</style>
