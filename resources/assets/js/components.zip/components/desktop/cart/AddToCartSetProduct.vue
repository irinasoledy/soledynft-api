<template>
    <div class="descr">
        <a :href="'/' + $lang + '/' + site + '/catalog/' + product.category.alias + '/' + product.alias" class="name">{{ product.translation.name }}</a>

        <div class="price" v-if="product.subproducts.length == 0">
            <div v-if="set.gift_product_id !== product.id">
                <span>
                    <span>
                        {{ product.personal_price.price }}
                        <span v-if="product.personal_price.price == product.personal_price.old_price">
                            {{ $currency }}
                        </span>
                    </span>
                </span>
                <span v-if="product.personal_price.price !== product.personal_price.old_price">
                    / {{ product.personal_price.old_price }} {{ $currency }}
                </span>
            </div>
            <div v-else>
                <span>
                    <span>
                        {{ product.personal_price.set_price }}
                        <span v-if="product.personal_price.set_price == product.personal_price.old_price">
                            {{ $currency }}
                        </span>
                    </span>
                </span>
                <span v-if="product.personal_price.set_price !== product.personal_price.old_price">
                    / {{ product.personal_price.old_price }} {{ $currency }}
                </span>
            </div>
        </div>

        <div class="dropdown sizeContainer" v-if="product.subproducts.length > 0">
            <div>
                <span>{{ trans.vars.DetailsProductSet.size }}</span><span><img src="/fronts/img/icons/ruler.svg" alt="icon" /><a href="#" data-toggle="modal" data-target="#modalSize">{{ trans.vars.DetailsProductSet.sizeGuide }}</a></span>
            </div>
            <button class="animated dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Select size
            </button>
            <div class="dropdown-menu chooseSize" aria-labelledby="dropdownMenuButton">
                <label class="selSize" v-for="subproduct in product.subproducts" :value="subproduct.parameter_value.translation.name" @click="setProduct(product, subproduct)">
                    <input type="radio" name="size1" :disabled="subproduct.warehouse.stock == 0" :value="subproduct.parameter_value.translation.name" />
                    <span class="check">
                        <span>{{ subproduct.parameter_value.translation.name }}</span>
                        <span v-if="subproduct.warehouse.stock > 0">in stoc</span>
                        <span v-if="subproduct.warehouse.stock == 0">not in stoc</span>
                    </span>
                </label>
            </div>
        </div>

        <div class="buttonsSet" v-if="product.subproducts.length > 0">
            <div class="wishButton" @click="addToFavorites(product)">
                <span>
                    {{ btnWish }}
                    <svg width="31px" height="26px" viewBox="0 0 31 26" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="wishButton" transform="translate(-1447.000000, -245.000000)" fill="#42261D" fill-rule="nonzero"> <g id="header"> <g id="project_20200129_150142" transform="translate(0.000000, 72.000000)"> <g id="Group-8"> <g id="Group-16" transform="translate(0.500000, 0.000000)"> <g id="Shape-3" transform="translate(1446.500000, 173.000000)"> <path d="M29.2285714,7.62639287 C29.2285714,6.65683111 29.1004619,5.80098339 28.8442429,5.05884971 C28.5880239,4.31671602 28.260302,3.72719853 27.861077,3.29029725 C27.4618521,2.85339596 26.9762277,2.49729149 26.4042039,2.22198384 C25.8321801,1.94667618 25.2720734,1.76114276 24.7238839,1.66538357 C24.1756944,1.56962438 23.5917535,1.52174479 22.972061,1.52174479 C22.3523686,1.52174479 21.6850074,1.67436099 20.9699777,1.9795934 C20.2549479,2.2848258 19.5965247,2.66786254 18.994708,3.12870362 C18.3928912,3.5895447 17.877474,4.02046104 17.4484561,4.42145263 C17.0194382,4.82244422 16.6619234,5.19051859 16.3759115,5.52567573 C16.1614025,5.78901349 15.869432,5.92068237 15.5,5.92068237 C15.130568,5.92068237 14.8385975,5.78901349 14.6240885,5.52567573 C14.3380766,5.19051859 13.9805618,4.82244422 13.5515439,4.42145263 C13.122526,4.02046104 12.6071088,3.5895447 12.005292,3.12870362 C11.4034753,2.66786254 10.7450521,2.2848258 10.0300223,1.9795934 C9.31499256,1.67436099 8.64763145,1.52174479 8.02793899,1.52174479 C7.40824653,1.52174479 6.82430556,1.56962438 6.27611607,1.66538357 C5.72792659,1.76114276 5.16781994,1.94667618 4.59579613,2.22198384 C4.02377232,2.49729149 3.53814794,2.85339596 3.13892299,3.29029725 C2.73969804,3.72719853 2.41197607,4.31671602 2.15575707,5.05884971 C1.89953807,5.80098339 1.77142857,6.65683111 1.77142857,7.62639287 C1.77142857,9.63733576 2.88568328,11.7619927 5.11419271,14.0003636 L15.5,24.0550781 L25.8679315,14.0183185 C28.1083581,11.7679776 29.2285714,9.63733576 29.2285714,7.62639287 Z M31,7.921875 C31,10.4157986 29.6795015,12.9548611 27.0385045,15.5390625 L16.2611607,25.6953125 C16.0535714,25.8984375 15.7998512,26 15.5,26 C15.2001488,26 14.9464286,25.8984375 14.7388393,25.6953125 L3.94419643,15.5052083 C3.82886905,15.4149306 3.6702939,15.2682292 3.46847098,15.0651042 C3.26664807,14.8619792 2.94661458,14.4924045 2.50837054,13.9563802 C2.07012649,13.4203559 1.67801339,12.8702257 1.33203125,12.3059896 C0.986049107,11.7417535 0.677548363,11.0590278 0.406529018,10.2578125 C0.135509673,9.45659722 5.32907052e-15,8.67795139 5.32907052e-15,7.921875 C5.32907052e-15,5.43923611 0.732328869,3.49826389 2.19698661,2.09895833 C3.66164435,0.699652778 5.68563988,-1.0658141e-14 8.26897321,-1.0658141e-14 C8.98400298,-1.0658141e-14 9.71344866,0.121310764 10.4573103,0.363932292 C11.2011719,0.606553819 11.8931362,0.933810764 12.5332031,1.34570312 C13.1732701,1.75759549 13.7239583,2.14409722 14.1852679,2.50520833 C14.6465774,2.86631944 15.0848214,3.25 15.5,3.65625 C15.9151786,3.25 16.3534226,2.86631944 16.8147321,2.50520833 C17.2760417,2.14409722 17.8267299,1.75759549 18.4667969,1.34570312 C19.1068638,0.933810764 19.7988281,0.606553819 20.5426897,0.363932292 C21.2865513,0.121310764 22.015997,-1.0658141e-14 22.7310268,-1.0658141e-14 C25.3143601,-1.0658141e-14 27.3383557,0.699652778 28.8030134,2.09895833 C30.2676711,3.49826389 31,5.43923611 31,7.921875 Z" id="Shape" ></path> </g> </g> </g> </g> </g> </g> </g> </svg>
                </span>
            </div>

            <div class="cartButton" @click="addToCartProduct(product)">
                <span>
                    {{ btnCart }}
                    <svg width="24px" height="32px" viewBox="0 0 24 32" version="1.1" xmlns="http://www.w3.org/2000/svg"> <g id="Symbols" stroke="none" strokewidth="1" fill="none" fillrule="evenodd"> <g id="project_20200129_150142" transform="translate(-1529.000000, -61.000000)"> <g transform="translate(-359.000000, -1055.000000)" id="Group-8"> <g id="Group-16" transform="translate(356.500000, 1055.000000)"> <g id="Shape-2" transform="translate(1532.050781, 61.363636)"> <path d="M4.56105523,8.4535472 L18.8601019,8.10653496 C21.0685906,8.0529389 22.9023727,9.79982458 22.9559687,12.0083133 C22.9589832,12.1325272 22.9562084,12.256814 22.9476534,12.3807696 L21.9919921,26.2275651 C21.8472458,28.324827 20.1037358,29.9521531 18.0014848,29.9521531 L5.04927707,29.9521531 C2.88525509,29.9521531 1.11363495,28.2311249 1.0509553,26.0680108 L0.65977772,12.5682275 C0.59579128,10.3600154 2.33402965,8.5180345 4.54224179,8.45404806 C4.54851254,8.45386635 4.5547837,8.4536994 4.56105523,8.4535472 Z" id="Rectangle" fill="none" opacity="0.916666667" transform="translate(11.896687, 18.976077) rotate(-360.000000) translate(-11.896687, -18.976077) " ></path> <path d="M22.5214956,7.96933632 L18.0691228,7.96933632 L18.0691228,6.17062023 C18.0691228,2.76285464 15.2646973,-1.11910481e-13 11.8056573,-1.11910481e-13 C8.34639139,-1.11910481e-13 5.5419659,2.76285464 5.5419659,6.17062023 L5.5419659,7.96933632 L0.721725511,7.96933632 C0.323804812,7.97044937 0.00112980001,8.28789607 1.95399252e-14,8.68036342 L1.95399252e-14,27.7180369 C0.000903851575,29.6810416 1.61586067,31.2720594 3.60817549,31.2727273 L19.6420505,31.2727273 C21.6345913,31.2720594 23.2495481,29.6810416 23.25,27.7180369 L23.25,8.68036342 C23.2454807,8.28656036 22.9207721,7.97000411 22.5214956,7.96933632 Z M6.75,6.20190826 C6.75,3.58021034 8.93286651,1.45454545 11.6248857,1.45454545 C14.3175905,1.45454545 16.5,3.58021034 16.5,6.20190826 L16.5,8 L6.75,8 L6.75,6.20190826 Z M21.75,27.6953403 C21.7464048,28.8665479 20.7846764,29.8148583 19.5973463,29.8181818 L3.6528784,29.8181818 C2.46509894,29.8148583 1.50337056,28.8665479 1.5,27.6953403 L1.5,9.45454545 L5.57566104,9.45454545 L5.57566104,12.3342628 C5.57566104,12.7251085 5.89721089,13.0419505 6.29313742,13.0419505 C6.68951332,13.0419505 7.01083843,12.7251085 7.01083843,12.3342628 L7.01083843,9.45454545 L16.6049779,9.45454545 L16.6049779,12.3342628 C16.6049779,12.7251085 16.926303,13.0419505 17.3226789,13.0419505 C17.7186054,13.0419505 18.0401552,12.7251085 18.0401552,12.3342628 L18.0401552,9.45454545 L21.75,9.45454545 L21.75,27.6953403 Z" id="Shape" fill="#42261D" fillrule="nonzero" transform="translate(11.625000, 15.636364) rotate(-360.000000) translate(-11.625000, -15.636364) " ></path> </g> </g> </g> </g> </g> </svg>
                </span>
            </div>
        </div>

        <div v-if="site == 'bijoux'">
            <div v-if="product.warehouse.stock === 0">
                {{ trans.vars.DetailsProductSet.outOfStock }}
            </div>
        </div>

    </div>
</template>

<script>
    import { bus } from "../../../app_desktop";
    export default {
        props: ["product", "site", "set"],
        data() {
            return {
                subproducts: [],
                subproduct: [],
                btnCart: trans.vars.Cart.cartAddTo,
                btnWish: trans.vars.Cart.cartAddTo,
            };
        },
        mounted() {
            // console.log(this.set);
        },
        methods: {
            addToFavorites(product) {
                axios
                    .post("/" + this.$lang + "/" + this.site + "/add-to-favorites", {
                        product_id: product.id,
                    })
                    .then((response) => {
                        this.addAnimation("wish", this.$el);
                        this.btnWish = trans.vars.Cart.cartAddedTo;
                        bus.$emit("updateWishBox", {
                            data: response.data,
                        });
                    })
                    .catch((e) => {
                        console.log("add favorites error");
                    });
            },
            addToCartProduct(product) {
                if (product.subproducts.length > 0) {
                    if (this.subproduct.warehouse.stock > 0) {
                        this.addProductToCartAction(product);
                    } else {
                        $(this.$el).find(".chooseSize").addClass("heartBeat");
                        setInterval(() => {
                            $(this.$el).find(".chooseSize").removeClass("heartBeat");
                        }, 2000);
                    }
                } else {
                    this.addProductToCartAction(product);
                }
            },
            addProductToCartAction(product) {
                axios
                    .post("/" + this.$lang + "/" + this.site + "/add-product-to-cart", {
                        productId: product.id,
                        subproductId: this.subproduct.id,
                    })
                    .then((response) => {
                        this.addAnimation("cart", this.$el);
                        this.btnCart = trans.vars.Cart.cartAddedTo;
                        bus.$emit("updateCartBox", { data: response.data });
                        bus.$emit("updateCart", this.subproduct.code);
                        bus.$emit("ga-event-addToCart", { product: this.product, actionField: this.product.translation.name });
                    })
                    .catch((e) => {
                        this.errors.push(e);
                    });
            },
            setProduct(product, subproduct) {
                if (subproduct.warehouse.stock == 0) {
                    $(".disabled").removeClass("selected");
                } else {
                    this.btnCart = trans.vars.Cart.cartAddTo;
                }
                this.product = product;
                this.subproduct = subproduct;
            },
            addAnimation(el, target) {
                document.getElementById(el).classList.add("heartBeat");
                if (el == "cart") {
                    $(target).find(".cartButton").addClass("elAdded");
                } else if (el == "wish") {
                    $(target).find(".wishButton").addClass("elAdded");
                } else {
                    return null;
                }
                setInterval(() => {
                    document.getElementById(el).classList.remove("heartBeat");
                }, 2000);
            },
        },
    };
</script>
<style media="screen">
    .collectionContent .sizeContainer div:first-child {
        display: flex;
    }
    .disabled {
        opacity: 0.4;
        cursor: default !important;
    }
    .gift-icon{
        width: 25px !important;
        display: inline;
        margin-top: -8px;
        margin-left: 40px;
    }
</style>
