@extends('front.desktop.app')
@section('content')
@include('front.desktop.partials.header')
<main class="clientArea">
    <div class="container">
        <h3>{{ trans('vars.Cabinet.yourOrderHistory') }}</h3>
        <div class="row">
            <div class="col-auto">
                <div class="navArea" id="navArea">
                    <div class="user">
                        <p>{{ trans('vars.General.hello') }}, {{ $userdata->name }}</p>
                        <p>{{ trans('vars.Cabinet.welcomeTo') }} {{ trans('vars.Cabinet.yourOrderHistory') }}</p>
                    </div>
                    @include('front.desktop.account.accountMenu')
                </div>
            </div>
            <div class="col">
                <div class="orderHistory">
                    @if ($orders->count() > 0)
                    @foreach ($orders as $key => $order)
                    @php
                    $status = 'delivered';
                        if ($order->main_status == 'inway') { $status = 'indelivering'; }
                        if ($order->main_status == 'cancelled') { $status = 'notRespond'; }
                    @endphp
                    <div class="row order">
                        <div class="col-auto">
                            <p>
                                <span>{{ trans('vars.Cabinet.order') }} Nr. {{ $order->order_hash }} </span>
                                <span class="status {{ $status }}">{{ $order->main_status }}</span>
                            </p>
                            <p>{{ trans('vars.Cabinet.atDate') }}:  {{ date('d-m-Y', strtotime($order->change_status_at)) }}</p>
                            <p>{{ trans('vars.Cabinet.amount') }}: {{ $order->amount }} {{ $order->currency->abbr }}</p>
                        </div>
                        <div class="col-auto buttons">
                            <a href="{{ url('/'.$lang->lang.'/account/history/order/'.$order->id) }}"><button>{{ trans('vars.Cabinet.ordersDetails') }}</button></a>
                        </div>
                    </div>
                    @endforeach
                    @else
                    <div class="col">
                        <p class="text-center">{{ trans('vars.Cabinet.youHaveNoOrders') }}</p>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
    </div>
</main>
@include('front.desktop.partials.footer')
@stop
