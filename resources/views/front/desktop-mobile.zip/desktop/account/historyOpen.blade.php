@extends('front.desktop.app')
@section('content')
@include('front.desktop.partials.header')
<main class="clientArea">
    <div class="container">
        <h3>{{ trans('vars.Cabinet.yourOrderHistory') }}</h3>
        <div class="row">
            <div class="col-auto">
                <div class="navArea" id="navArea">
                    <div class="user">
                        <p>{{ trans('vars.General.hello') }}, {{ $userdata->name }}</p>
                        <p>{{ trans('vars.Cabinet.welcomeTo') }} {{ trans('vars.Cabinet.yourOrderHistory') }}</p>
                    </div>
                    @include('front.desktop.account.accountMenu')
                </div>
            </div>
            <div class="col">
                <div class="row oneHistory">
                    <div class="col-12">
                        <p class="titleOne">
                            <span>{{ trans('vars.Cabinet.order') }} {{ trans('vars.Cabinet.nr') }} {{ $order->order_hash }}</span>
                            <span class="status delivered">{{ $order->main_status }}</span>
                        </p>
                    </div>
                    <div class="col-12">
                        <div class="row justify-content-between">
                            <div class="col-auto orderDetails">
                                <p>{{ trans('vars.Cabinet.contactData') }}</p>
                                <span>{{ $order->details->contact_name }}</span>
                                <span>+{{ $order->details->code }} {{ $order->details->phone }}</span>
                                <span>{{ $order->details->email }}</span>
                            </div>
                            <div class="col-auto orderDetails">
                                <p>{{ trans('vars.Cabinet.shipiingAddress') }}</p>
                                <span>{{ $order->details->country }}</span>
                                <span>
                                    @if ($order->details->region)
                                        {{ $order->details->region }},
                                    @endif
                                        {{ $order->details->city }},
                                        {{ $order->details->address }},
                                    @if ($order->details->zip)
                                        {{ $order->details->zip }}
                                    @endif
                                </span>
                            </div>
                            <div class="col-auto orderDetails">
                                <p>{{ trans('vars.Cabinet.shipping/payment') }}</p>
                                <span>{{ $order->details->delivery }}/{{ $order->payment_id }}</span>
                                <span>{{ trans('vars.Cabinet.amount') }}: {{ $order->amount }} {{ $order->currency->abbr }}</span>
                            </div>
                            @if ($order->tracking_link)
                                <div class="col-auto orderDetails">
                                    <p>{{ trans('vars.Cabinet.trackingNumber') }}</p>
                                    <span><a target="_blank" href="{{ $order->tracking_link }}">{{ $order->tracking_link }}</a></span>
                                </div>
                            @endif
                        </div>
                    </div>

                    <div class="col-12">
                        <p class="titleOne">
                            {{ trans('vars.Cabinet.products') }}:
                        </p>
                        <div class="row productsList">
                            <div class="col-12">
                                @if ($order->orderSubproducts()->count() > 0)
                                @foreach ($order->orderSubproducts as $key => $subproduct)
                                <div class="row cartItem">
                                    <a class="col-auto" href="{{ url('/'.$lang->lang.'/homewear/catalog/'.$subproduct->subproduct->product->category->alias.'/'.$subproduct->subproduct->product->alias) }}">
                                    @if ($subproduct->subproduct->product->mainImage)
                                    <img src="/images/products/og/{{ $subproduct->subproduct->product->mainImage->src }}" alt="" />
                                    @else
                                    <img src="/fronts/img/prod/oneProduct.jpg" alt="" />
                                    @endif
                                    </a>
                                    <div class="description col-auto">
                                        <a href="{{ url('/'.$lang->lang.'/homewear/catalog/'.$subproduct->subproduct->product->category->alias.'/'.$subproduct->subproduct->product->alias) }}">
                                        {{ $subproduct->subproduct->product->translation->name }}
                                        </a>
                                        <div class="params">
                                            <span>{{ trans('vars.Cabinet.qty') }}: {{ $subproduct->qty }}</span>
                                        </div>
                                    </div>
                                    <div class="price col-auto">
                                        <span>{{ $subproduct->subproduct->product->personalPrice->price }} {{ $currency->abbr }}</span>
                                    </div>
                                </div>
                                @endforeach
                                @endif
                                @if ($order->orderProducts()->count() > 0)
                                @foreach ($order->orderProducts as $key => $product)
                                <div class="row cartItem">
                                    <a class="col-auto" href="{{ url('/'.$lang->lang.'/bijoux/catalog/' .$product->product->category->alias.'/'.$product->product->alias) }}">
                                    @if ($product->product->mainImage)
                                    <img src="/images/products/og/{{ $product->product->mainImage->src }}" alt="" />
                                    @else
                                    <img src="/fronts/img/prod/oneProduct.jpg" alt="" />
                                    @endif
                                    </a>
                                    <div class="description col-auto">
                                        <a href="{{ url('/'.$lang->lang.'/bijoux/catalog/' .$product->product->category->alias.'/'.$product->product->alias)  }}">
                                        {{ $product->product->translation->name }}
                                        </a>
                                        <div class="params">
                                            <span>{{ trans('vars.Cabinet.qty') }}: {{ $product->qty }}</span>
                                        </div>
                                    </div>
                                    <div class="price col-auto">
                                        @if ($product->set_id)
                                            <span>{{ $product->product->personalPrice->set_price }} {{ $currency->abbr }}</span>
                                        @else
                                            <span>{{ $product->product->personalPrice->price }} {{ $currency->abbr }}</span>
                                        @endif
                                    </div>
                                </div>
                                @endforeach
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <p class="titleOne">
                            {{ trans('vars.Cabinet.amount') }}: {{ $order->amount }} {{ $order->currency->abbr }}
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@include('front.desktop.partials.footer')
@stop
