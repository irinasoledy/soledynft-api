<header class="loungewear">
    <ul class="nav">
        <li class="burger">
            <div id="burger">
                <div class="iconBar"></div>
            </div>
        </li>
        <li class="logoCenter"><a href="{{ url('/'.$lang->lang.'/') }}"><img src="/fronts/img/icons/logonew.png" alt="" /></a></li>
        <ul class="settings">
                        <li>
                                <wish-counter :items="{{ $wishProducts }}" class="animated"  id="wish" site="loungewear"></wish-counter>

                        </li>
                        <li>
                                <cart-counter :items="{{ $cartProducts }}" class="animated" site="loungewear" id="cart"></cart-counter>

                        </li>
                        <li>
                            @if (Auth::guard('persons')->user())
                                <a href="{{ url('/'.$lang->lang.'/account/personal-data') }}" id="avatar">
                            @else
                                <a href="" id="avatar" data-toggle="modal" data-target="#auth">
                            @endif
                                <svg viewBox="0 0 28 28" version="1.1" xmlns="http://www.w3.org/2000/svg"> <g id="Symbols" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd"> <g id="project_20200129_150142" transform="translate(-1603.000000, -68.000000)"> <g transform="translate(-359.000000, -1053.000000)" id="Group-8"> <g> <g id="Group-16" transform="translate(355.500000, 1024.000000)"> <g id="Group-5" transform="translate(1606.500000, 97.000000)"> <path d="M14.4899419,27.375 C19.1843623,27.375 23,25.448744 23,23.5485015 C23,21.648259 19.1944204,14.625 14.5,14.625 C9.80557963,14.625 6,21.648259 6,23.5485015 C6,25.448744 9.79552154,27.375 14.4899419,27.375 Z" id="Oval-Copy" fill="none" opacity="0.946289062" ></path> <path d="M13.9898467,5.0655891e-05 C8.33156474,5.0655891e-05 3.23053052,3.40856172 1.06529337,8.63617717 C-1.09994384,13.8635529 0.0967607314,19.8806675 4.09767994,23.8818509 C7.62931266,27.4281256 12.7864312,28.8175386 17.6216642,27.5254349 C22.4568971,26.2335708 26.2334792,22.4567259 27.5255751,17.6217029 C28.8174312,12.7864403 27.4280267,7.62929018 23.8817738,4.0976358 C21.2640274,1.46549269 17.7019558,-0.00996461351 13.9898467,5.0655891e-05 Z M6.4275749,24.2634182 L6.4275749,23.052805 C6.4275749,18.8764169 9.81324461,15.4904868 13.9898467,15.4904868 C18.1664488,15.4904868 21.5521185,18.8764169 21.5521185,23.052805 L21.5521185,24.2634182 C17.0565071,27.5815195 10.9231863,27.5815195 6.4275749,24.2634182 Z M22.779262,23.2347205 L22.779262,23.052805 C22.779262,18.2065171 18.8363445,14.2635754 13.9898467,14.2635754 C9.14334894,14.2635754 5.2004314,18.2065171 5.2004314,23.052805 L5.2004314,23.2347205 C2.66249733,20.8295524 1.22563691,17.4862849 1.22755241,13.9896235 C1.22755241,6.95243969 6.95270599,1.22725285 13.9898467,1.22725285 C21.0269874,1.22725285 26.7521406,6.95243969 26.7521406,13.9896235 C26.7538168,17.4862849 25.3171961,20.8295524 22.7790223,23.2347205 L22.779262,23.2347205 Z" id="Shape" fill="#42261D" fillRule="nonzero" ></path> <circle id="Oval" fill="none" opacity="0.946289062" cx="14" cy="9" r="4"></circle> <path d="M14,4 C11.2386438,4 9,6.23864382 9,9 C9,11.7613562 11.2386438,14 14,14 C16.7613561,14 19,11.7613562 19,9 C18.9967156,6.239907 16.7600929,4.0032843 14,4 Z M14,12.7064827 C11.95311,12.7064827 10.2935173,11.04689 10.2935173,8.99999997 C10.2935173,6.95285737 11.95311,5.29351726 14,5.29351726 C16.0471427,5.29351726 17.7064827,6.95285737 17.7064827,8.99999997 C17.7042089,11.0461321 16.046132,12.704209 14,12.7064827 Z" id="Shape" fill="#42261D" fillRule="nonzero" ></path> </g> </g> </g> </g> </g> </g> </svg>
                            </a>
                        </li>
                        <li>
                            <settings-modal
                                    :countries="{{ $countries }}"
                                    :country="{{ $country }}"
                                    :currencies="{{ $currencies }}"
                                    :currency="{{ $currency }}"
                                    :langs="{{ $langs }}"
                                    :lang="{{ $lang }}"
                                ></settings-modal>

                            {{-- <a href="#" id="settings" data-toggle="modal" data-target="#userSettings">
                                @if ($country->iso != "MD")
                                    {{ $currency->abbr }} /
                                @else
                                    MDL /
                                @endif
                                {{ $lang->lang }} /
                                <span><img src="/images/flags/24x24/{{ $country->flag }}" alt="icon" /></span>
                            </a> --}}
                        </li>
                    </ul>
    </ul>
    <div class="navOpen" id="navOpen">
        <!-- <ul class="settings">
            <li class="widthSettings" data-toggle="modal" data-target="#userSettings">
                <p>
                    {{ $currency->abbr }} / {{ $lang->lang }} / <img src="/images/flags/24x24/{{ $country->flag }}" alt="icon" />
                </p>
                <p>|</p>
                <a data-toggle="modal" data-target="#userSettings">{{ trans('vars.TehButtons.change') }}</a>
            </li>
        </ul> -->

        <div class="navCollection2">
            <span id="collectionButton" class="collectionThis">Bijuterii Catalog</span>
            <ul class="navOpen" id="collectionsOpen">
                <li class="navBack"><span>Bijuterii Catalog</span></li>

                @if ($categoriesMenuJewelry->count() > 0)
                    <li class="collButton">
                        <a href="{{ url('/'.$lang->lang.'/bijoux/catalog/all') }}">
                            <span>Toate Produsele</span>
                        </a>
                    </li>
                    @foreach ($categoriesMenuJewelry as $key => $category)
                        <li class="collButton">
                            <a href="{{ url('/'.$lang->lang.'/bijoux/catalog/'. $category->alias) }}">
                                <span>{{ $category->translation->name }}</span>
                            </a>
                        </li>
                    @endforeach
                @endif
            </ul>
        </div>

        <div class="navCollection2">
            <span id="collectionButton" class="collectionThis">Colectii de Bijuterii</span>
            <ul class="navOpen" id="collectionsOpen">
                <li class="navBack"><span>Colectii de Bijuterii</span></li>
                @if ($collectionsMenuJewelry->count() > 0)
                    @foreach ($collectionsMenuJewelry as $key => $collection)
                        <li class="collButton">
                            <a href="{{ url('/'.$lang->lang.'/bijoux/collection/'. $collection->alias) }}">
                                <span>{{ $collection->translation->name }}</span>
                            </a>
                        </li>
                    @endforeach
                @endif
            </ul>
        </div>

        <div class="navCollection2">
            <span id="collectionButton" class="collectionThis">Homewear Catalog</span>
            <ul class="navOpen" id="collectionsOpen">
                <li class="navBack"><span>Homewear Catalog</span></li>
                @if ($categoriesMenuLoungewear->count() > 0)
                    <li class="collButton">
                        <a href="{{ url('/'.$lang->lang.'/homewear/catalog/all') }}">
                            <span>Toate Produsele</span>
                        </a>
                    </li>
                    @foreach ($categoriesMenuLoungewear as $key => $category)
                        <li class="collButton">
                            <a href="{{ url('/'.$lang->lang.'/homewear/catalog/'. $category->alias) }}">
                                <span>{{ $category->translation->name }}</span>
                            </a>
                        </li>
                    @endforeach
                @endif
            </ul>
        </div>

        <div class="navCollection2">
            <span id="collectionButton"  class="collectionThis">Colectii Homewear</span>
            <ul class="navOpen" id="collectionsOpen">
                <li class="navBack"><span>Colectii Homewear</span></li>

                @if ($collectionsMenuLoungewear->count() > 0)
                    @foreach ($collectionsMenuLoungewear as $key => $collection)
                        <li class="collButton">
                            <a href="{{ url('/'.$lang->lang.'/homewear/collection/'. $collection->alias) }}">
                                <span>{{ $collection->translation->name }}</span>
                            </a>
                        </li>
                    @endforeach
                @endif
            </ul>
        </div>

        <a href="{{ url('/'.$lang->lang.'/promos') }}">{{ trans('vars.PagesNames.pagePromotions') }}</a>
        <a href="{{ url('/'.$lang->lang.'/new') }}">{{ trans('vars.HeaderFooter.newIn') }}</a>
        <a href="{{ url('/'.$lang->lang.'/sale') }}">{{ trans('vars.HeaderFooter.outlet') }}</a>
        <a href="{{ url($lang->lang.'/about/')}}">{{ trans('vars.PagesNames.pageAboutUs') }}</a>

        @if (Auth::guard('persons')->user())
            <a  href="{{ url('/'.$lang->lang.'/account/personal-data') }}" id="avatar">
        @else
            <a href="" id="avatar" data-toggle="modal" data-target="#auth">
        @endif
            Account
        </a>

        <div class="navCollection2">
            <span id="categoryButton">
                {{ trans('vars.General.helpInformation') }}
                <svg width="6px" height="14px" viewBox="0 0 6 14" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> <title>Shape</title> <desc>Created with Sketch.</desc> <g id="AnaPopova-Site" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Burger_375---new" transform="translate(-310.000000, -173.000000)" fill="#42261D" fill-rule="nonzero"> <path d="M316,179.999496 C315.994424,179.76069 315.929214,179.61673 315.845738,179.513407 L311.263173,173.291465 C311.046736,172.9548 310.556192,172.901525 310.249549,173.174905 C309.942871,173.448285 309.926585,173.959445 310.172633,174.263643 L313.818842,179.221754 C314.053173,179.555878 314.170339,179.815125 314.170339,179.999496 C314.170339,180.183867 314.053173,180.443114 313.818842,180.777238 L310.172633,185.735345 C309.893521,186.042592 309.972834,186.58149 310.267456,186.870577 C310.494222,187.093127 311.098625,187.022197 311.263173,186.707523 L315.845738,180.485585 C315.965078,180.324437 316.001411,180.204626 316,179.999496 Z" id="Shape"></path> </g> </g> </svg>
            </span>
            <ul class="navOpen navOneCollection" id="categoryOpen">
                <li>
                    <span><a href="{{ url('/'.$lang->lang.'/contacts') }}">{{ trans('vars.Contacts.contactsTitle') }}</a></span>
                </li>
                <li>
                    <span><a href="{{ url('/'.$lang->lang.'/livrare-achitare-retur') }}">{{ trans('vars.DetailsProductSet.shippingPaymentReturns') }}</a></span>
                </li>
                <li>
                    <span><a href="{{ url('/'.$lang->lang.'/size-guide') }}">{{ trans('vars.PagesNames.pageSizeGuide') }}</a></span>
                </li>
            </ul>
        </div>
        <div class="networks">
            <p>{{ trans('vars.HeaderFooter.followUs') }}:</p>
            <ul class="dspflex">
                <li>
                    <a href="{{ trans('vars.Contacts.instagram') }}">
                        <svg width="18px" height="18px" viewBox="0 0 18 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" > <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Footer" transform="translate(-1548.000000, -431.000000)" fill="#B22D00" fill-rule="nonzero" > <g id="social"> <g transform="translate(1410.000000, 427.000000)"> <g id="instagram-social-network-logo-of-photo-camera" transform="translate(64.000000, 4.000000)" > <path d="M76.3103887,0 L89.6897961,0 C90.9604082,0 92,0.940705375 92,2.31018019 L92,15.6898198 C92,17.0592946 90.9604082,18 89.6897961,18 L76.3103887,18 C75.0394069,18 74,17.0592946 74,15.6898198 L74,2.31018019 C74,0.940705375 75.0394069,0 76.3103887,0 L76.3103887,0 Z M87.8865291,2 C87.398665,2 87,2.40944718 87,2.91045938 L87,5.08954062 C87,5.59034519 87.398665,6 87.8865291,6 L90.1130663,6 C90.6009304,6 91,5.59034519 91,5.08954062 L91,2.91045938 C91,2.40944718 90.6009304,2 90.1130663,2 L87.8865291,2 L87.8865291,2 Z M89.9996295,8 L88.4115078,8 C88.5617606,8.4706196 88.6430935,8.96914225 88.6430935,9.48490436 C88.6430935,12.3640726 86.1315936,14.6979761 83.0340894,14.6979761 C79.9367705,14.6979761 77.4256412,12.3640726 77.4256412,9.48490436 C77.4256412,8.96878679 77.5067888,8.47044187 77.6572268,8 L76,8 L76,15.3118432 C76,15.6902228 76.3227377,16 76.7173597,16 L89.2826403,16 C89.6772623,16 90,15.6904006 90,15.3118432 L90,8 L89.9996295,8 Z M83.4998211,6 C81.5670467,6 80,7.56690234 80,9.5 C80,11.4330977 81.5670467,13 83.4998211,13 C85.4327744,13 87,11.4330977 87,9.5 C87,7.56690234 85.4329533,6 83.4998211,6 Z" id="Shape" ></path> </g> </g> </g> </g> </g> </svg>
                    </a>
                </li>
                <li>
                    <a href="/">
                        <svg width="10px" height="19px" viewBox="0 0 10 19" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" > <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Footer" transform="translate(-1732.000000, -428.000000)" fill="#B22D00" fill-rule="nonzero" > <g id="social"> <g transform="translate(1410.000000, 427.000000)"> <path d="M330.187221,4.15465514 C328.766054,4.15465514 328.490905,4.82104815 328.490905,5.79901691 L328.490905,7.95536596 L331.880335,7.95536596 L331.879135,11.3329419 L328.490905,11.3329419 L328.490905,20 L324.955596,20 L324.955596,11.3329419 L322,11.3329419 L322,7.95536596 L324.955596,7.95536596 L324.955596,5.46473443 C324.955596,2.57406965 326.745162,1 329.358574,1 L332,1.00414645 L331.9998,4.15386534 L330.187221,4.15465514 Z" id="Shape-Copy" transform="translate(327.000000, 10.500000) rotate(-360.000000) translate(-327.000000, -10.500000) " ></path> </g> </g> </g> </g> </svg>
                    </a>
                </li>
            </ul>
        </div>
    </div>

</header>

{{--
  <ul class="nav">

      <li>
          <cart-counter-mob class="animated" id="cart" :items="{{ $cartProducts }}" site="loungewear">
          </cart-counter-mob>
      </li>
  </ul>
  <div class="navOpen" id="navOpen">
      <ul class="settings">
          <li class="widthSettings" data-toggle="modal" data-target="#userSettings">
              <p>
                  {{ $currency->abbr }} / {{ $lang->lang }} / <img src="/images/flags/24x24/{{ $country->flag }}" alt="icon" />
              </p>
              <p>|</p>
              <a data-toggle="modal" data-target="#userSettings">{{ trans('vars.TehButtons.change') }}</a>
          </li>
      </ul>

      <div class="navCollection2">
          <span id="collectionButton">Bijuterii Catalog</span>
          <ul class="navOpen" id="collectionsOpen">
              <li class="navBack"><span>Bijuterii Catalog</span></li>

              @if ($categoriesMenuJewelry->count() > 0)
                  <li class="collButton">
                      <a href="{{ url('/'.$lang->lang.'/bijoux/catalog/all') }}">
                          <span>Toate Produsele</span>
                      </a>
                  </li>
                  @foreach ($categoriesMenuJewelry as $key => $category)
                      <li class="collButton">
                          <a href="{{ url('/'.$lang->lang.'/bijoux/catalog/'. $category->alias) }}">
                              <span>{{ $category->translation->name }}</span>
                          </a>
                      </li>
                  @endforeach
              @endif
          </ul>
      </div>

      <div class="navCollection2">
          <span id="collectionButton">Colectii de Bijuterii</span>
          <ul class="navOpen" id="collectionsOpen">
              <li class="navBack"><span>Colectii de Bijuterii</span></li>
              @if ($collectionsMenuJewelry->count() > 0)
                  @foreach ($collectionsMenuJewelry as $key => $collection)
                      <li class="collButton">
                          <a href="{{ url('/'.$lang->lang.'/homewear/collection/'. $collection->alias) }}">
                              <span>{{ $collection->translation->name }}</span>
                          </a>
                      </li>
                  @endforeach
              @endif
          </ul>
      </div>

      <div class="navCollection2">
          <span id="collectionButton">Homewear Catalog</span>
          <ul class="navOpen" id="collectionsOpen">
              <li class="navBack"><span>Homewear Catalog</span></li>
              @if ($categoriesMenuLoungewear->count() > 0)
                  <li class="collButton">
                      <a href="{{ url('/'.$lang->lang.'/homewear/catalog/all') }}">
                          <span>Toate Produsele</span>
                      </a>
                  </li>
                  @foreach ($categoriesMenuLoungewear as $key => $category)
                      <li class="collButton">
                          <a href="{{ url('/'.$lang->lang.'/homewear/catalog/'. $category->alias) }}">
                              <span>{{ $category->translation->name }}</span>
                          </a>
                      </li>
                  @endforeach
              @endif
          </ul>
      </div>

      <div class="navCollection2">
          <span id="collectionButton">Colectii Homewear</span>
          <ul class="navOpen" id="collectionsOpen">
              <li class="navBack"><span>Colectii Homewear</span></li>

              @if ($collectionsMenuLoungewear->count() > 0)
                  @foreach ($collectionsMenuLoungewear as $key => $collection)
                      <li class="collButton">
                          <a href="{{ url('/'.$lang->lang.'/homewear/collection/'. $collection->alias) }}">
                              <span>{{ $collection->translation->name }}</span>
                          </a>
                      </li>
                  @endforeach
              @endif
          </ul>
      </div>

      <a href="{{ url('/'.$lang->lang.'/new') }}">{{ trans('vars.HeaderFooter.newIn') }}</a>
      <a href="{{ url('/'.$lang->lang.'/sale') }}">{{ trans('vars.HeaderFooter.outlet') }}</a>
      <a href="{{ url($lang->lang.'/about/')}}">{{ trans('vars.PagesNames.pageAboutUs') }}</a>

      @if (Auth::guard('persons')->user())
          <a  href="{{ url('/'.$lang->lang.'/account/personal-data') }}" id="avatar">
      @else
          <a href="" id="avatar" data-toggle="modal" data-target="#auth">
      @endif
          Account
      </a>
      <div class="navCollection2">
          <span id="categoryButton">
              {{ trans('vars.General.helpInformation') }}
              <svg width="6px" height="14px" viewBox="0 0 6 14" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> <title>Shape</title> <desc>Created with Sketch.</desc> <g id="AnaPopova-Site" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Burger_375---new" transform="translate(-310.000000, -173.000000)" fill="#42261D" fill-rule="nonzero"> <path d="M316,179.999496 C315.994424,179.76069 315.929214,179.61673 315.845738,179.513407 L311.263173,173.291465 C311.046736,172.9548 310.556192,172.901525 310.249549,173.174905 C309.942871,173.448285 309.926585,173.959445 310.172633,174.263643 L313.818842,179.221754 C314.053173,179.555878 314.170339,179.815125 314.170339,179.999496 C314.170339,180.183867 314.053173,180.443114 313.818842,180.777238 L310.172633,185.735345 C309.893521,186.042592 309.972834,186.58149 310.267456,186.870577 C310.494222,187.093127 311.098625,187.022197 311.263173,186.707523 L315.845738,180.485585 C315.965078,180.324437 316.001411,180.204626 316,179.999496 Z" id="Shape"></path> </g> </g> </svg>
          </span>
          <ul class="navOpen navOneCollection" id="categoryOpen">
              <li>
                  <span><a href="{{ url('/'.$lang->lang.'/contacts') }}">{{ trans('vars.Contacts.contactsTitle') }}</a></span>
              </li>
              <li>
                  <span><a href="{{ url('/'.$lang->lang.'/livrare-achitare-retur') }}">{{ trans('vars.DetailsProductSet.shippingPaymentReturns') }}</a></span>
              </li>
              <li>
                  <span><a href="{{ url('/'.$lang->lang.'/size-guide') }}">{{ trans('vars.PagesNames.pageSizeGuide') }}</a></span>
              </li>
          </ul>
      </div>
      <div class="networks">
          <p>{{ trans('vars.HeaderFooter.followUs') }}:</p>
          <ul class="dspflex">
              <li>
                  <a href="{{ trans('vars.Contacts.instagram') }}">
                      <svg width="18px" height="18px" viewBox="0 0 18 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" > <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Footer" transform="translate(-1548.000000, -431.000000)" fill="#B22D00" fill-rule="nonzero" > <g id="social"> <g transform="translate(1410.000000, 427.000000)"> <g id="instagram-social-network-logo-of-photo-camera" transform="translate(64.000000, 4.000000)" > <path d="M76.3103887,0 L89.6897961,0 C90.9604082,0 92,0.940705375 92,2.31018019 L92,15.6898198 C92,17.0592946 90.9604082,18 89.6897961,18 L76.3103887,18 C75.0394069,18 74,17.0592946 74,15.6898198 L74,2.31018019 C74,0.940705375 75.0394069,0 76.3103887,0 L76.3103887,0 Z M87.8865291,2 C87.398665,2 87,2.40944718 87,2.91045938 L87,5.08954062 C87,5.59034519 87.398665,6 87.8865291,6 L90.1130663,6 C90.6009304,6 91,5.59034519 91,5.08954062 L91,2.91045938 C91,2.40944718 90.6009304,2 90.1130663,2 L87.8865291,2 L87.8865291,2 Z M89.9996295,8 L88.4115078,8 C88.5617606,8.4706196 88.6430935,8.96914225 88.6430935,9.48490436 C88.6430935,12.3640726 86.1315936,14.6979761 83.0340894,14.6979761 C79.9367705,14.6979761 77.4256412,12.3640726 77.4256412,9.48490436 C77.4256412,8.96878679 77.5067888,8.47044187 77.6572268,8 L76,8 L76,15.3118432 C76,15.6902228 76.3227377,16 76.7173597,16 L89.2826403,16 C89.6772623,16 90,15.6904006 90,15.3118432 L90,8 L89.9996295,8 Z M83.4998211,6 C81.5670467,6 80,7.56690234 80,9.5 C80,11.4330977 81.5670467,13 83.4998211,13 C85.4327744,13 87,11.4330977 87,9.5 C87,7.56690234 85.4329533,6 83.4998211,6 Z" id="Shape" ></path> </g> </g> </g> </g> </g> </svg>
                  </a>
              </li>
              <li>
                  <a href="/">
                      <svg width="10px" height="19px" viewBox="0 0 10 19" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" > <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Footer" transform="translate(-1732.000000, -428.000000)" fill="#B22D00" fill-rule="nonzero" > <g id="social"> <g transform="translate(1410.000000, 427.000000)"> <path d="M330.187221,4.15465514 C328.766054,4.15465514 328.490905,4.82104815 328.490905,5.79901691 L328.490905,7.95536596 L331.880335,7.95536596 L331.879135,11.3329419 L328.490905,11.3329419 L328.490905,20 L324.955596,20 L324.955596,11.3329419 L322,11.3329419 L322,7.95536596 L324.955596,7.95536596 L324.955596,5.46473443 C324.955596,2.57406965 326.745162,1 329.358574,1 L332,1.00414645 L331.9998,4.15386534 L330.187221,4.15465514 Z" id="Shape-Copy" transform="translate(327.000000, 10.500000) rotate(-360.000000) translate(-327.000000, -10.500000) " ></path> </g> </g> </g> </g> </svg>
                  </a>
              </li>
          </ul>
      </div>
  </div>
  --}}
