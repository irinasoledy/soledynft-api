@extends('front.desktop.app')
@section('content')
@include('front.desktop.partials.header')
<main class="promo collectionContent">
    <div class="titlePage">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3>{{ trans('vars.PagesNames.pagePromotions') }} {{ $promotion->translation->name }}</h3>
                </div>
            </div>
        </div>
    </div>

    <section>
        @if ($promotion->img)
            <img src="/images/promotions/{{ $promotion->img }}" alt="{{ $promotion->translation->name }}">
        @endif

        @foreach ($promotion->sets as $key => $setItem)
        @if ($setItem->set->id != Request::get('order'))
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h4>{{ $setItem->set->translation->name }}</h4>
                    </div>
                    <div class="col-lg-7 col-md-6">
                        <div class="mainSlider">
                            <div class="sliderContainer slideHome">
                                <div class="navCollection">
                                    @if ($setItem->set->photos()->count() > 0)
                                        @foreach ($setItem->set->photos as $key => $photo)
                                            <img src="/images/sets/sm/{{ $photo->src }}"/>
                                        @endforeach
                                    @endif
                                </div>
                                <div class="oneCollectionSlider">
                                    @if ($setItem->set->photos()->count() > 0)
                                        @foreach ($setItem->set->photos as $key => $photo)
                                            <div><img src="/images/sets/og/{{ $photo->src }}"/></div>
                                        @endforeach
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-6">
                        <set :set="{{ $setItem->set }}" site="{{ $site }}"></set>
                    </div>
                </div>
            </div>
        </section>
        @endif
        @endforeach

    </section>
</main>
@include('front.desktop.partials.footer')
@stop
