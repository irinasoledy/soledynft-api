@extends('front.desktop.app')
@section('content')
@include('front.desktop.partials.header')
    <main class="categoryContent">

        <div class="container">
            <div class="row">
                <div class="col-12">
                  <h3>
                    @if ($site == 'homewear')
                        {{ trans('vars.General.homewearCatalog') }}
                    @else
                        {{ trans('vars.General.bijouxCatalog') }}
                    @endif
                  </h3>
                </div>
                @foreach ($products as $key => $product)
                    @if ($product->mainImage)
                        <div class="col-md-4">
                            <div class="oneCateProd">
                                <div class="oneProduct">
                                    <div class="addToWish"></div>
                                    <a class="imgBlock" href="{{ url('/'. $lang->lang . '/'. $product->type . '/catalog/' . $product->category->alias . '/' . $product->alias) }}">
                                        @if ($product->mainImage)
                                            <img src="/images/products/og/{{ $product->mainImage->src }}"/>
                                        @endif
                                    </a>
                                    <a href="{{ url('/'. $lang->lang . '/'. $product->type . '/catalog/' . $product->category->alias . '/' . $product->alias) }}">{{ $product->translation->name }}</a>
                                    <div class="price">
                                        @if ($product->personalPrice->price == $product->personalPrice->old_price)
                                            <span>
                                                {{ $product->personalPrice->price }}
                                                <span>{{ $currency->abbr }}</span>
                                            </span>
                                        @else
                                            <span>
                                                {{ $product->personalPrice->price }}
                                            </span>
                                            <span>
                                                 / {{ $product->personalPrice->old_price }}
                                            </span>
                                            <span>{{ $currency->abbr }}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </main>
@include('front.desktop.partials.footer')
@stop
